package com.bjpowernode.service;

import java.math.BigDecimal;

public interface AccountService {
    BigDecimal getMoney(Long uid);

    void insert(Long id);

    int deduction(Long uid, Integer money);
}
