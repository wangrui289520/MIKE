package com.bjpowernode.model;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Data
public class BidInfo implements Serializable {
    private Long id;
    private Long prodId;
    private Long uid;
    private BigDecimal bidMoney;
    private Date bidTime;
    private Integer bidStatus;

    private Product product;
    private User user;
}
