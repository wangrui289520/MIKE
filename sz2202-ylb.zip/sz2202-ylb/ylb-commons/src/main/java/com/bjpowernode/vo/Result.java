package com.bjpowernode.vo;

import lombok.Data;

@Data
public class Result {
    private String code;
    private Boolean success;
    private String message;
    private String serialNo;
    private String comfrom;
}
