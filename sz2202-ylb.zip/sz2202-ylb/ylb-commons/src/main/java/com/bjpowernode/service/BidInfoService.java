package com.bjpowernode.service;

import com.bjpowernode.model.BidInfo;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

public interface BidInfoService {
    BigDecimal getSumMoney();
    List<Map> getTop3();
    List<BidInfo> getForLimit(Integer uid, Integer limit);

    List<BidInfo> getListByProductId(Long productId, Integer limit);

    void bid(Long uid, Long pid, Integer money);

    List<BidInfo> getByProductId(Long id);
}
