package com.bjpowernode.vo;

import lombok.Data;

import java.io.Serializable;

/*
    {
        "code":"10000",
        "charge":false,
        "remain":0,
        "msg":"查询成功",
        "requestId":"a43fb154347e4939a6ccf356c8425bfa",
        "result":
            {
                "code":"000000",
                "success":"true",
                "message":"一致",
                "serialNo":"202206211152038943253023539223",
                "comfrom":"jd_credit_two"
            }

   }
 */

@Data
public class RealNameResultVo implements Serializable {
    private String code;
    private String charge;
    private String remain;
    private String msg;
    private String requestId;

    private Result result;
}
