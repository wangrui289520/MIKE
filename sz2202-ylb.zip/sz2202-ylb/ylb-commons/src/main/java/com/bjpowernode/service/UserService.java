package com.bjpowernode.service;

import com.bjpowernode.model.User;

public interface UserService {
    void register(User user);

    boolean checkExists(String phone);

    User getLoginUser(String phone, String password);

    User getByPhone(String phone);

    Integer getCount();

    void realName(Long userId, String name, String idCard);

    void updateLastLoginTime(String phone);
}
