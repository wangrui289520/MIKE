package com.bjpowernode.service;

import com.bjpowernode.model.Product;
import com.bjpowernode.vo.Page;

import java.util.Date;

public interface ProductService {
    Double getAvgRate(); // 查询产品平局利率
    Product getNewProduct(); // 新手宝产品
    /*
        根据类型和周期查询一条：首页展示除了新手宝之外其它产品（散标和优选各3个（满月宝、季度宝、双季宝））
        优选类：
            满月宝：getByTypeAndCycle(1, 1);
            季度宝：getByTypeAndCycle(1, 3);
            双季宝：getByTypeAndCycle(1, 6);

        散标类：
            满月宝：getByTypeAndCycle(2, 1);
            季度宝：getByTypeAndCycle(2, 3);
            双季宝：getByTypeAndCycle(2, 6);
     */
    Product getByTypeAndCycle(Integer type, Integer cycle);

    /**
     *
     * @param type  产品类型：1优选 2散标
     * @param pageSize  每页展示条数
     * @param currPage  第几页
     * @return  分页对象
     */
    Page getPage(Integer type, Integer pageSize, Integer currPage);

    Product getById(Long id);

    int deduction(Long pid, Integer money);

    void setFull(Long pid, Date date);

    void scanFullProduct();
}
