package com.bjpowernode.model;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Data
public class Product implements Serializable {
    private Long id; // id, 主键
    private String productName; // 产品名称
    private BigDecimal rate; // 产品利率
    private Integer cycle; // 产品期限
    private Date releaseTime; // 发布时间
    private Integer productType; // 产品类型：0新手宝1优选产品2散标产品
    private String productNo; // 产品编号
    private BigDecimal productMoney; // 产品可购买金额
    private BigDecimal leftProductMoney; // 产品剩余可购买金额
    private BigDecimal bidMinLimit; // 最低投资金额
    private BigDecimal bidMaxLimit; // 最高投资金额
    private Integer productStatus;// 产品状态：0:未满标,1:满标(leftProductMoney为0时),2: 已生成收益计划
    private Date productFullTime; // 产品满标时间
    private String productDesc; // 产品描述
}
