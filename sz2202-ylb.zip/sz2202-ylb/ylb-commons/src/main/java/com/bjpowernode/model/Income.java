package com.bjpowernode.model;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;

@Data
public class Income implements Serializable {
    private Long id;
    private Long uid;
    private Long prodId;
    private Long bidId;
    private BigDecimal bidMoney;
    private Date incomeDate;
    private BigDecimal incomeMoney;
    private Integer incomeStatus;
}
