package com.bjpowernode.vo;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class Page implements Serializable {
    private Integer totalPage; // 总页数
    private List items; // 分页的数据
}
