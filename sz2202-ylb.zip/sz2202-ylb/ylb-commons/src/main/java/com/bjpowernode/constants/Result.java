package com.bjpowernode.constants;

import java.util.HashMap;
import java.util.Map;


public interface Result {
    Map SUC = new HashMap() {{
        put("success", true);
    }};

    Map SUC_TIP = new HashMap() {{
        put("success", true);
        put("msg", "操作成功！");
    }};

    Map FAIL_TIP = new HashMap() {{
        put("success", false);
        put("msg", "服务器忙，请稍后再试！");
    }};
}
