<template>
  <div>{{sumMoney}}<i>元</i></div>
</template>

<script>
import Vue from "vue";

export default {
  name: "SumMoney",
  data() {
    return {
      sumMoney: 0
    }
  },
  created() {
    Vue.axios.get('http://127.0.0.1/bid/sumMoney').then(({data}) => {
      this.sumMoney = data.toFixed(2);
    });
  }
}
</script>

<style scoped>

</style>