<template>
  <div class="public-head">
    <div class="public-head-nav">
      <div class="public-head-left">
        <h1 class="public-head-logo">
          <a href="javascript:;">
            <!-- /表示public目录 -->
            <img src="/image/logo.png" alt="">
          </a>
        </h1>
        <ul class="public-head-list">
          <li><a href="javascript:;" @click="$router.push('/index')">主页</a></li>
          <li class="public-head-hover">
            <a href="javascript:;">我要投资</a>
            <!--二级导航-->
            <div class="two-title">
              <a href="javascript:;" @click="toLink('/list/1')">优先类产品</a>
              <a href="javascript:;" @click="toLink('/list/2')">散标类产品</a>
            </div>
          </li>
          <li><a href="javascript:;" @click="$router.push('/user')">个人中心</a></li>
          <li><a href="javascript:;">信息披露</a></li>
          <li><a href="javascript:;">安全计划</a></li>
        </ul>
      </div>
      <div v-show="!isLogin" class="public-head-right">
        <a style="color:red;" href="javascript:;" @click="$router.push('/login')">登录</a>
        <a href="javascript:;" @click="$router.push('/')">注册</a>
      </div>
    </div>
  </div>
  <!--end-->
</template>

<script>
export default {
  name: "Header",
  computed: {
    isLogin() {
      return !!sessionStorage.getItem("ylb-token")
    }
  },
  methods: {
    toLink(path) {
      location = path;
    }
  }
}
</script>

<style scoped>

</style>