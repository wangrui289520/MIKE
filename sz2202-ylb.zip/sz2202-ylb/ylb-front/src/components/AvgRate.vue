<template>
  <div>{{avgRate}}<i>%</i></div>
</template>

<script>
import Vue from "vue";

export default {
  name: "AvgRate",
  data() {
    return {
      avgRate: 0
    }
  },
  created() {
    Vue.axios.get('/product/avgRate').then(({data}) => {
      this.avgRate = data.toFixed(2);
    });
  }
}
</script>

<style scoped>

</style>