<template>
  <div>{{userCount}}<i>位</i></div>
</template>

<script>
import Vue from "vue";

export default {
  name: "UserCount",
  data() {
    return {
      userCount: 0
    }
  },
  created() {
    Vue.axios.get('http://127.0.0.1/user/userCount').then(({data}) => {
      this.userCount = data;
    });
  }
}
</script>

<style scoped>

</style>