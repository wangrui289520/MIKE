<template>
  <li>
    <h3 v-if="product.productType==1" class="preferred-select-title">
      <span>{{ itemTitle }}</span>
      <img :src="itemBg" alt="">
    </h3>
    <h3 v-else class="preferred-select-title1">{{ product.productName }}
      <span style="color: gold; font-weight: bold;">散标</span>
    </h3>
    <div class="preferred-select-number">
      <p><b>{{ product.rate.toFixed(2) }}</b>%</p>
      <span>历史年化收益率</span>
    </div>
    <div class="preferred-select-date">
      <div>
        <span>投资周期</span>
        <p><b>{{ product.cycle }}</b>个月</p>
      </div>
      <div>
        <span>余利可投资金额</span>
        <p :class="{'preferred-select-date-no': !product.leftProductMoney}"><b>{{
            product.leftProductMoney.toFixed(2)
          }}</b>元</p>
      </div>
    </div>
    <p class="preferred-select-txt">
      {{ product.productDesc }}
    </p>
    <button @click="invest(product.id)"
            :disabled="product.leftProductMoney==0"
            :style="{
              border: 'none',
              background: product.leftProductMoney==0?'#BCC0CB':'',
              cursor: product.leftProductMoney==0?'':'pointer'
            }"
            class="preferred-select-btn">立即投资
    </button>
  </li>
</template>

<script>
export default {
  name: "ProductItem",
  methods: {
    invest(id) {
      this.$router.push("/detail/" + id);
    }
  },
  props: {
    product: Object
  },
  computed: {
    itemTitle() {
      // return this.product.cycle == 1 ? '满月宝' : this.product.cycle == 3 ? '季度宝' : '双季宝';
      if (this.product.cycle == 1) {
        return '满月宝'
      } else if (this.product.cycle == 3) {
        return '季度宝'
      } else if (this.product.cycle == 6) {
        return '双季宝'
      } else if (this.product.cycle == 12) {
        return '年度宝'
      } else if (this.product.cycle == 24) {
        return '双年宝'
      } else if (this.product.cycle == 36) {
        return '三年宝'
      } else if (this.product.cycle == 60) {
        return '五年宝'
      } else {
        return "xxx宝";
      }
    },
    itemBg() {
      if (this.product.cycle == 1) {
        return '/image/1-bg1.jpg'
      } else if (this.product.cycle == 3) {
        return '/image/1-bg2.jpg'
      } else if (this.product.cycle == 6) {
        return '/image/1-bg3.jpg'
      } else {
        return '/image/1-bg4.jpg'
      }
    }
  }
}
</script>

<style scoped>

</style>