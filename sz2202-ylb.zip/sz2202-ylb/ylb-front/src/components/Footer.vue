<template>
  <div class="public-bottom">
    <div>
      <p>版权所有 ©2017 北京动力节点教育科技有限公司 京ICP备09027468号 | 京公网安备京公网安备11030808027468</p>
      <p>一家只教授Java的培训机构<a href="javascript:;">Visit the HomePage</a></p>
    </div>
  </div>
</template>

<script>
export default {
  name: "Footer"
}
</script>

<style scoped>

</style>