<template>
  <div>
    <!--头部-->
    <Header/>

    <div class="login-content">
      <div class="login-flex">
        <div class="login-left"></div>
        <!---->
        <div class="login-box">
          <h3 class="login-title">实名认证</h3>
          <form action="" id="renZ_Submit">
            <div class="alert-input">
              <input type="text" class="form-border user-name"
                     v-model="name"
                     @blur="checkName"
                     @input="nameTip=''"
                     name="username"
                     placeholder="请输入您的真实姓名">
              <p class="prompt_name">{{ nameTip }}</p>
              <input type="text" class="form-border user-sfz"
                     v-model="idCard"
                     @input="idCardTip=''"
                     @blur="checkIdCard"
                     name="sfz" placeholder="请输入15位或18位身份证号">
              <p class="prompt_sfz">{{ idCardTip }}</p>
              <!--              <input type="text" class="form-border user-num" name="mobile" placeholder="请输入11位手机号">
                            <p class="prompt_num"></p>
                            <div class="form-yzm form-border">
                              <input class="yzm-write" type="text" placeholder="输入短信验证码">
                              <input class="yzm-send" type="text" value="获取验证码" disabled="disabled" id="yzmBtn" readonly="readonly" >
                            </div>
                            <p class="prompt_yan"></p>-->
            </div>
            <div class="alert-input-agree">
              <input type="checkbox" v-model="agree"/>
              我已阅读并同意<a href="javascript:;" target="_blank">《动力金融网注册服务协议》</a>
            </div>
            <div class="alert-input-btn">
              <input type="button" class="login-submit"
                     :disabled="!canAuth"
                     :style="{background: bgColor}"
                     @click="auth"
                     value="认证">
            </div>
          </form>
          <div class="login-skip">
            暂不认证？ <a href="javascript:;">跳过</a>
          </div>
        </div>

      </div>
    </div>

    <!--公共底部-->
    <Footer/>
  </div>
</template>

<script>
import Footer from "@/components/Footer";
import Header from "@/components/Header";
import Vue from "vue";

export default {
  name: "AuthView",
  data() {
    return {
      name: '',
      idCard: '',
      agree: false,

      nameTip: '',
      idCardTip: '',
    }
  },
  methods: {
    checkName() {
      if (!this.name) {
        this.nameTip = "请输入姓名！";
      } else if (!this.isName) {
        this.nameTip = "姓名不合法！";
      } else {
        this.nameTip = '';
      }
    },
    checkIdCard() {
      if (!this.idCard) {
        this.idCardTip = "请输入身份证！";
      } else if (!this.isIdCard) {
        this.idCardTip = "身份证格式不正确！";
      } else {
        this.idCardTip = '';
      }
    },
    auth() {
      if (this.agree) {
        let url = "/user/auth/" + this.name + "/" + this.idCard;
        Vue.axios.get(url).then(({data}) => {
          if (data.result.success == "true") {
            this.$router.push("/index");
          } else {
            this.$alert('姓名和身份证号不匹配，请确认！', '提示', {
              confirmButtonText: '确定',
            });
          }
        });
      } else {
        this.$alert('请勾选同意协议！', '提示', {
          confirmButtonText: '确定',
        });
      }
    }
  },
  computed: {
    isName() {
      return /^[\u4e00-\u9fa5]{2,}$/.test(this.name)
    },
    isIdCard() {
      return /(^\d{15}$)|(^\d{17}(\d|X|x)$)/.test(this.idCard);
    },
    canAuth() {
      return this.isName && this.isIdCard;
    },
    bgColor() {
      return this.canAuth ? '' : '#ccc';
    }
  },
  components: {Header, Footer}
}
</script>

<style scoped>

</style>