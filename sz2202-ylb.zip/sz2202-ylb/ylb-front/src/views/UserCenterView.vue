<template>
  <div>
    <Header/>
    <div class="content clearfix">
      <!--个人信息-->
      <div class="user-head">
        <div class="user-head-left fl">
          <div class="user-head-img">
            <img src="/image/user-head.png" alt="">
          </div>
          <p>上传头像</p>
        </div>
        <div class="user-head-right fl">
          <ul class="user-head-name fl">
            <li><b>{{ userInfo.name }}</b></li>
            <li>{{ userInfo.phone }}</li>
            <li>最近登录：{{ userInfo.lastLoginTime | formatDate }}</li>
          </ul>
          <div class="user-head-money fr">
            <p>可用余额：<span>{{ money | formatMoney }}</span></p>
            <button v-show="!show" @click="showMoney(true)">显示余额</button>
            <button v-show="show" @click="showMoney(false)">隐藏余额</button>
            <a href="javascript:;" @click="$router.push('/pay')" class="user-head-a1">充值</a>
            <a href="details.html" class="user-head-a2">投资</a>
          </div>
        </div>

      </div>
      <!--记录-->
      <div class="user-record-box clearfix">
        <div class="user-record user-record-1">
          <h3 class="user-record-title">最近投资</h3>
          <table v-show="bidRecord.length > 0" align="center" width="388" border="0" cellspacing="0" cellpadding="0">
            <thead class="datail_thead">
            <tr>
              <th>投资产品</th>
              <th>投资金额</th>
              <th>投资时间</th>
            </tr>
            </thead>
            <tbody>
            <tr v-for="b in bidRecord">
              <td>{{ b.product.productName }}</td>
              <td>{{ b.bidMoney }}</td>
              <td>{{ b.bidTime | formatDate }}</td>
            </tr>
            </tbody>
          </table>
          <!--无记录-->
          <p v-show="bidRecord.length == 0" class="user-record-no">还没有投资记录，请投资：<a href="user_center.html" target="_blank">投资</a></p>
        </div>
        <div class="user-record user-record-2">
          <h3 class="user-record-title">最近充值</h3>
          <table align="center" width="388" border="0" cellspacing="0" cellpadding="0">
            <thead class="datail_thead">
            <tr>
              <th>序号</th>
              <th>充值描述</th>
              <th>充值金额</th>
              <th>充值时间</th>
            </tr>
            </thead>
            <tbody>
            <tr>
              <td>1</td>
              <td>新手宝</td>
              <td>1500.0</td>
              <td>2021-08-19</td>
            </tr>
            <tr>
              <td>2</td>
              <td>新手宝</td>
              <td>1500.0</td>
              <td>2021-08-19</td>
            </tr>
            <tr>
              <td>3</td>
              <td>新手宝</td>
              <td>1500.0</td>
              <td>2021-08-19</td>
            </tr>
            <tr>
              <td>4</td>
              <td>新手宝</td>
              <td>1500.0</td>
              <td>2021-08-19</td>
            </tr>
            <tr>
              <td>5</td>
              <td>新手宝</td>
              <td>1500.0</td>
              <td>2021-08-19</td>
            </tr>
            <tr>
              <td>6</td>
              <td>新手宝</td>
              <td>1500.0</td>
              <td>2021-08-19</td>
            </tr>
            </tbody>
          </table>
          <!--无记录-->
          <p class="user-record-no">还没有充值记录，请充值：<a href="user_pay.html" target="_blank">充值</a></p>
        </div>
        <div class="user-record user-record-3">
          <h3 class="user-record-title ">最近收益</h3>
          <table align="center" width="388" border="0" cellspacing="0" cellpadding="0">
            <thead class="datail_thead">
            <tr>
              <th>序号</th>
              <th>项目名称</th>
              <th>投资日期</th>
              <th>收益金额</th>
            </tr>
            </thead>
            <tbody>
            <tr>
              <td>1</td>
              <td>新手宝</td>
              <td>2021-08-19</td>
              <td>0.46</td>
            </tr>
            <tr>
              <td>2</td>
              <td>新手宝</td>
              <td>2021-08-19</td>
              <td>0.46</td>
            </tr>
            <tr>
              <td>3</td>
              <td>新手宝</td>
              <td>2021-08-19</td>
              <td>0.46</td>
            </tr>
            <tr>
              <td>4</td>
              <td>新手宝</td>
              <td>2021-08-19</td>
              <td>0.46</td>
            </tr>
            <tr>
              <td>5</td>
              <td>新手宝</td>
              <td>2021-08-19</td>
              <td>0.46</td>
            </tr>
            <tr>
              <td>6</td>
              <td>新手宝</td>
              <td>2021-08-19</td>
              <td>0.46</td>
            </tr>
            </tbody>
          </table>
          <!--无记录-->
          <p class="user-record-no">还没有收益记录</p>
        </div>
      </div>
    </div>
    <Footer/>
  </div>
</template>

<script>
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import Vue from "vue";
import {formatDate, formatMoney} from "@/utils/formatUtils";


export default {
  name: "UserCenterView",
  data() {
    return {
      show: false,
      userInfo: JSON.parse(sessionStorage.getItem("ylb-userInfo")) || {},
      money: '******',
      bidRecord: [],
    }
  },
  created() {
    Vue.axios.get("/bid/limit/6").then(({data}) => this.bidRecord = data);
  },
  methods: {
    showMoney(show) {
      this.show = show;
      if (!show) {
        this.money = '******';
      } else {
        Vue.axios.get("/account/money").then(({data}) => this.money = data)
      }
    }
  },
  filters: {formatDate, formatMoney},
  components: {Footer, Header}
}

</script>

<style scoped>

</style>