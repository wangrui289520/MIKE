<template>
  <div>
    <!--头部-->
    <Header/>

    <div class="login-content">
      <div class="login-flex">
        <div class="login-left">
          <h3>加入动力金融网</h3>
          <p>坐享<span> <AvgRate /> </span>历史年化收益</p>
          <p>平台用户<span> <UserCount /> </span></p>
          <p>累计成交金额<span><SumMoney /></span></p>
        </div>
        <!---->
        <div class="login-box">
          <h3 class="login-title">
            <a href="javascript:;" @click="changeLoginType(true)" :class="{active: pwdLogin}">密码登录</a>
            <span class="shu"></span>
            <a href="javascript:;" @click="changeLoginType(false)" :class="{active: !pwdLogin}">短信登录</a>
          </h3>
          <!-- 密码登录表单 -->
          <form action="" id="login_Submit" v-show="pwdLogin">
            <div class="alert-input">
              <input type="text" class="form-border user-num"
                     @blur="checkPhone"
                     @input="phoneTip=''"
                     v-model="phone"
                     placeholder="请输入11位手机号">
              <p class="prompt_num">{{ phoneTip }}</p>
              <input type="password" placeholder="请输入登录密码"
                     @blur="checkPassword"
                     @input="passwordTip=''"
                     v-model="password"
                     class="form-border user-pass" autocomplete name="password">
              <p class="prompt_pass">{{ passwordTip }}</p>
            </div>
            <div class="alert-input-btn">
              <input type="button" @click="loginForPwd" :disabled="!canLogin" :style="{background: bgColor}"
                     class="login-submit" value="登录">
            </div>
          </form>

          <!-- 短信登录 -->
          <form action="" id="login_Submit2" v-show="!pwdLogin">
            <div class="alert-input">
              <input type="text" class="form-border user-num"
                     @blur="checkPhone"
                     @input="phoneTip=''"
                     v-model="phone"
                     placeholder="请输入11位手机号">
              <p class="prompt_num">{{ phoneTip }}</p>
              <div class="form-yzm form-border">
                <input class="yzm-write"
                       @blur="checkCode"
                       @input="inputCode"
                       type="text" v-model="code" placeholder="输入短信验证码">
                <input class="yzm-send" type="text" :value="sendText"
                       @click="sendSMS"
                       :disabled="!isPhone || remainingSendTime > 0"
                       id="yzmBtn" readonly="readonly">
              </div>
              <p class="prompt_yan">{{ codeTip }}</p>
            </div>
            <div class="alert-input-btn">
              <input type="button" @click="loginForSms"
                     :disabled="!canLogin2"
                     :style="{background: bgColor2}"
                     class="login-submit" value="登录">
            </div>
          </form>

        </div>

      </div>
    </div>

    <!--公共底部-->
    <Footer/>
  </div>
</template>

<script>
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import Vue from "vue";
import AvgRate from "@/components/AvgRate";
import UserCount from "@/components/UserCount";
import SumMoney from "@/components/SumMoney";


export default {
  name: "LoginView",
  data() {
    return {
      pwdLogin: true,
      phone: '',
      phoneTip: '',
      password: '',
      passwordTip: '',
      code: '',
      codeTip: '',
      remainingSendTime: 0,// 短信剩余发送时间
      realCode: '',
      avgRate: 0,
      userCount: 0,
      sumMoney: 0,
    }
  },
  methods: {
    inputCode() {
      this.codeTip = '';
      if (this.code.length == 6) {
        if (this.code != this.realCode) {
          this.codeTip = "短信验证码不正确";
        }
      }
    },
    sendSMS() {
      let url = 'http://127.0.0.1/sms/send/login/' + this.phone;
      Vue.axios.get(url).then(({data}) => {
        this.realCode = data;
        console.log(data);

        // 60秒倒计时
        this.remainingSendTime = 5;

        // 1000毫秒之后执行参数1指定的函数，只执行1次
        //setTimeout(() => console.log("xxx"), 1000)

        // 每秒执行一次, flag标识用于停止该计时器
        let flag = setInterval(() => {
          this.remainingSendTime--;
          if (this.remainingSendTime == 0) {
            clearInterval(flag) // 停止计时器
          }
        }, 1000);


      })
    },
    changeLoginType(pwdLogin) {
      // 切换到密码登录，清空短信登录的验证码信息
      // 切换到密码登录，并且当前是短信登录时，才执行清空操作
      if (pwdLogin && !this.pwdLogin) {
        this.phoneTip = '';
        this.code = '';
        this.codeTip = '';
      }
      // 切换到短信登录，清空密码登录的密码信息
      else if (!pwdLogin && this.pwdLogin) {
        this.phoneTip = '';
        this.password = '';
        this.passwordTip = '';
      }

      this.pwdLogin = pwdLogin;

    },
    checkPhone() {
      if (!this.phone) {
        this.phoneTip = "请输入手机号！";
      } else if (!this.isPhone) {
        this.phoneTip = "手机号格式不正确！"
      } else {
        this.phoneTip = ''
      }
    },
    checkCode() {
      if (!this.code) {
        this.codeTip = "请输入验证码！";
      } else if (!this.isCode) {
        this.codeTip = "验证码必须是6位数字！"
      } else {
        this.inputCode();
      }
    },
    checkPassword() {
      if (!this.password) {
        this.passwordTip = "请输入密码！";
      } else if (!this.isPassword) {
        this.passwordTip = "密码格式必须是包含数字和字母，长度6-20位！"
      } else {
        this.passwordTip = ''
      }
    },
    // 密码登录
    loginForPwd() {
      let data = "phone=" + this.phone + "&password=" + this.password;
      this.login("http://127.0.0.1/user/loginForPwd", data);
    },
    login(url, data) {
      Vue.axios.post(url, data).then(({data}) => {
        if (data.success) {
          /*
            将token和用户信息存储到 sessionStorage 对象中，该对象中的数据是会话级别的
            关闭浏览器之后会自动删除，如果需要永久存储，需要使用 localStorage 对象
            两个对象中都包含3个主要的方法：
              xxxStorage.setItem(key, value)
              xxxStorage.getItem(key)
              xxxStorage.removeItem(key)

            注意：这两个对象仅支持存储字符串！！！如果希望存储对象或者数组，
            必须先将其转换为字符串(JSON)：let str = JSON.stringify(对象或数组)
            并在取出时再将字符串转换为数组或对象：let obj = JSON.parse(字符串)
           */

          // 存令牌
          sessionStorage.setItem("ylb-token", data.token);
          let user = JSON.stringify(data.loginUser);
          sessionStorage.setItem("ylb-userInfo", user);
          // 如果用户已经实名认证，则跳转到产品首页，否则跳转到实名认证页面
          if (data.loginUser.name && data.loginUser.idCard) {
            this.$router.push('/index')
          } else {
            this.$router.push('/auth')
          }
        } else {
          // ElementUI 提示框
          this.$alert(data.msg, '提示', {
            confirmButtonText: '确定',
          });
        }
      })
    },
    // 短信登录
    loginForSms() {
      let data = "phone=" + this.phone + "&code=" + this.code;
      this.login("http://127.0.0.1/user/loginForSms", data);
    }
  },
  computed: {
    sendText() {
      if (this.remainingSendTime == 0) {
        return "获取验证码";
      } else {
        return "重新发送(" + this.remainingSendTime + "...)"
      }
    },
    isPhone() {
      return /^1[3-9]\d{9}$/.test(this.phone);
    },
    isPassword() {
      return /^(?=.*[0-9])(?=.*[a-zA-Z])[0-9a-zA-Z]{6,20}$/.test(this.password);
    },
    isCode() {
      return /^\d{6}$/.test(this.code)
    },
    bgColor() {
      return this.canLogin ? '' : '#ccc';
    },
    canLogin() {
      return this.isPhone && this.isPassword;
    },

    bgColor2() {
      return this.canLogin2 ? '' : '#ccc';
    },
    canLogin2() {
      return this.isPhone && this.isCode && this.code == this.realCode;
    }
  },
  components: {SumMoney, UserCount, AvgRate, Footer, Header}
}
</script>

<style scoped>
.active {
  color: #4fa5d9;
}

span.shu {
  width: 1px;
  height: 20px;
  background-color: #e7e7e7;
  margin: 0 21px;
  display: inline-block;
}
</style>