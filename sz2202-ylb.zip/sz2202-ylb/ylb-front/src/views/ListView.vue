<template>
  <div>
    <Header />

    <div class="content clearfix">
      <!--排行榜-->
      <ul class="rank-list">
        <li v-for="(t,i) in top3">
          <img :src="'/image/list-rank' + (i + 1) +'.png'" alt="">
          <p class="rank-list-phone">{{ t.phone }}</p>
          <span>{{ t.totalMoney.toFixed(2) }}元</span>
        </li>
      </ul>
      <!--产品列表-->
      <ul class="preferred-select clearfix">
        <ProductItem v-for="product in items" :product="product" />
      </ul>

      <!--分页-->
      <div class="page_box">
        <ul class="pagination">
          <li class="disabled">
            <a href="javascript:;" :style="backStyle" @click="goPage(1)"><span>首页</span></a>
          </li>
          <li>
            <a href="javascript:;" :style="backStyle" @click="goPage(currPage - 1)">上一页</a>
          </li>

          <li class="active"><span>{{ currPage }}</span></li>

          <li>
            <a href="javascript:;" :style="forwardStyle" @click="goPage(currPage + 1)">下一页</a>
          </li>
          <li>
            <a href="javascript:;" :style="forwardStyle" style="cursor: auto;" @click="goPage(totalPage)">尾页</a>
          </li>
          <li class="totalPages"><span>共{{ totalPage }}页</span></li>
        </ul>
      </div>
    </div>

    <Footer />
  </div>

</template>

<script>
import Vue from "vue";
import ProductItem from "@/components/ProductItem";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
export default {
  name: "ListView",
  components: {Footer, Header, ProductItem},
  data() {
    return {
      items: [],
      totalPage: 1,
      currPage: 1,
      top3: []
    }
  },
  methods: {
    goPage(currPage) {
      if (currPage < 1 || currPage > this.totalPage) {
        return;
      }

      let type = this.$route.params.type;
      this.currPage = currPage;
      // 请求后台接口，获取产品列表
      Vue.axios.get("/product/page/" + type + "/" + currPage).then(({data}) => {
        this.items = data.items;
        this.totalPage = data.totalPage;
      })
    }
  },
  created() {
    // 默认展示第1页
    this.goPage(1);

    // 获取投资排行前3名
    Vue.axios.get("/bid/top3").then(({data}) => this.top3 = data)
  },
  computed: {
    backStyle() {
      return {
        color: this.currPage == 1 ? '#ccc' : '',
        cursor: this.currPage == 1 ? 'auto' : '',
      }
    },
    forwardStyle() {
      return {
        color: this.currPage == this.totalPage ? '#ccc' : '',
        cursor: this.currPage == this.totalPage ? 'auto' : '',
      }
    }
  }
}
</script>

<style scoped>

</style>