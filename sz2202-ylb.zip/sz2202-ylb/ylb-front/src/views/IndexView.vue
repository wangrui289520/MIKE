<template>
  <div>
    <!--头部-->
    <Header/>

    <!--banner-->
    <div class="banner-content">
      <div class="swiper-container banner-lb">
        <div class="swiper-wrapper">
          <div class="swiper-slide">
            <a href="javascript:;">
              <img src="/image/banner.jpg" alt="">
            </a>
          </div>
          <div class="swiper-slide">
            <a href="javascript:;">
              <img src="/image/banner.jpg" alt="">
            </a>
          </div>
        </div>
      </div>
      <div class="banner-abs">
        <div class="banner-abs-box">
          <div class="banner-abs-title">动力金融网历史年化收益率</div>
          <b>
            <AvgRate/>
          </b>
          <p>平台用户数</p>
          <span><UserCount/></span>
          <p class="banner-abs-border">累计成交金额</p>
          <span><SumMoney/></span>
        </div>
      </div>
    </div>
    <div class="banner-list">
      <ul>
        <li>
          <img src="/image/banner-tag1.png" alt="">
          <p>
            <b>实力雄厚</b>
            <span>亿级注册资本 ,千万技术投入</span>
          </p>
        </li>
        <li>
          <img src="/image/banner-tag2.png" alt="">
          <p>
            <b>风控严苛</b>
            <span>30道风控工序，60项信用审核</span>
          </p>
        </li>
        <li>
          <img src="/image/banner-tag3.png" alt="">
          <p>
            <b>投资省心</b>
            <span>资金安全风控，银行安全托管</span>
          </p>
        </li>
      </ul>
    </div>

    <!-- 产品：新手宝 -->
    <div class="content">
      <h2 class="public-title"><span>新手宝</span></h2>
      <div class="new-user">
        <div class="new-user-sm">
          <span>{{ NProduct.bidMinLimit }}元起投</span>
          <span>投资最高限额{{ NProduct.bidMaxLimit }}元</span>
          <span>当日计息</span>
        </div>
        <div class="new-user-number">
          <ul>
            <li>
              <p><b>{{ NProduct.rate }}</b>%</p>
              <span>历史年化收益率</span>
            </li>
            <li>
              <p><b>{{ NProduct.cycle }}</b>个月</p>
              <span>投资周期</span>
            </li>
            <li>
              <p><b>{{ NProduct.leftProductMoney }}</b>元</p>
              <span>余利可投资金额</span>
            </li>
          </ul>
          <a href="details.html" target="_blank" class="new-user-btn">立即投资</a>
        </div>
        <span class="new-tag">新用户专享</span>
      </div>

      <h2 class="public-title"><span>优选产品</span>
        <a href="javascript:;" @click="toList(1)" class="public-title-more">查看更多产品>></a>
      </h2>
      <ul class="preferred-select clearfix">
        <!-- 优选满月宝 -->
        <ProductItem :product="Product11"/>
        <!-- 优选季度宝 -->
        <ProductItem :product="Product13"/>
        <!-- 优选双季宝 -->
        <ProductItem :product="Product16"/>
      </ul>

      <!--散标产品-->
      <h2 class="public-title">
        <span>散标产品</span>
        <a href="javascript:;" @click="toList(2)" class="public-title-more">查看更多产品>></a>
      </h2>
      <ul class="preferred-select clearfix">
        <ProductItem :product="Product21"/>
        <ProductItem :product="Product23"/>
        <ProductItem :product="Product26"/>
      </ul>

    </div>

    <!--说明-->
    <div class="information-box">
      <ul>
        <li>
          <img src="/image/2-icon1.png" alt="">
          <p>优质借款</p>
          <span>严苛风控，多重审核</span>

        </li>
        <li>
          <img src="/image/2-icon2.png" alt="">
          <p>次日计息</p>
          <span>闪电成交，谁比我快</span>
        </li>
        <li>
          <img src="/image/2-icon3.png" alt="">
          <p>全年无休</p>
          <span>百万用户，一路同行</span>
        </li>
        <li>
          <img src="/image/2-icon4.png" alt="">
          <p>知心托付</p>
          <span>百万用户，一路同行</span>
        </li>
        <li>
          <img src="/image/2-icon5.png" alt="">
          <p>技术保障</p>
          <span>千万投入，专注研发</span>
        </li>
      </ul>
    </div>

    <!--公共底部-->
    <Footer/>
  </div>
</template>

<script>
import Vue from "vue";
import Footer from "@/components/Footer";
import Header from "@/components/Header";
import AvgRate from "@/components/AvgRate";
import UserCount from "@/components/UserCount";
import SumMoney from "@/components/SumMoney";
import ProductItem from "@/components/ProductItem";
let ProductTemp = {
  "id": 64,
  "productName": "新手宝",
  "rate": 12.00,
  "cycle": 1,
  "releaseTime": "2017-07-25T16:00:00.000+00:00",
  "productType": 0,
  "productNo": "20170726",
  "productMoney": 10000.00,
  "leftProductMoney": 10000.00,
  "bidMinLimit": 100.00,
  "bidMaxLimit": 2000.00,
  "productStatus": 0,
  "productFullTime": null,
  "productDesc": "短期信贷金融消费产品"
};
export default {
  name: "IndexView",
  methods: {
    toList(type) {
      this.$router.push('/list/' + type);
    }
  },
  data() {
    return {
      NProduct: ProductTemp,
      Product11: ProductTemp,
      Product13: ProductTemp,
      Product16: ProductTemp,
      Product21: ProductTemp,
      Product23: ProductTemp,
      Product26: ProductTemp,
    }
  },
  created() {
    // 请求新手宝数据
    Vue.axios.get("/product/newProduct").then(({data}) => {
      this.NProduct = data;
    });
    let types = [1, 2];
    let cycles = [1, 3, 6];
    for (let type of types) {
      for (let cycle of cycles) {
        let url = "/product/" + type + "/" + cycle;
        Vue.axios.get(url).then(({data}) => {
          this["Product" + type + cycle] = data;
        });
      }
    }
  },
  components: {ProductItem, SumMoney, UserCount, AvgRate, Header, Footer}
}
</script>

<style scoped>

</style>