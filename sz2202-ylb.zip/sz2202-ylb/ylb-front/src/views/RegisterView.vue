<template>
  <!-- 所有的内容，必须放在一个根标签中 -->
  <div>
    <!--头部-->
    <Header/>

    <div class="login-content">
      <div class="login-flex">
        <div class="login-left">
          <p>万民用户知心托付&nbsp;&nbsp;&nbsp;&nbsp;<span>{{avgRate}}%</span>历史年化收益</p>
          <p>千万级技术研发投入&nbsp;&nbsp;&nbsp;&nbsp;亿级注册资本平台 </p>
        </div>
        <!---->
        <div class="login-box">
          <h3 class="login-title">用户注册</h3>
          <!-- autocomplete="off" 关闭自动提示  -->
          <form action="" id="register_Submit" autocomplete="off">
            <div class="alert-input">
              <input type="text" class="form-border user-num"
                     @blur="checkPhone"
                     @input="phoneTip=''"
                     v-model="phone" name="mobile" placeholder="请输入11位手机号">
              <p class="prompt_num">{{ phoneTip }}</p>
              <input type="text" v-model="password" placeholder="请输入6-20位英文和数字混合密码" class="form-border user-pass"
                     autocomplete name="password">
              <p class="prompt_pass">{{ passwordTip }}</p>
              <div class="form-yzm form-border">
                <input class="yzm-write" type="text" name="" v-model="code" placeholder="输入短信验证码">
                <input class="yzm-send" type="button" v-model="sendText"
                       @click="sendSMS"
                       :disabled="!isPhone || remainingSendTime > 0"
                       id="yzmBtn" readonly="readonly">
              </div>
              <p class="prompt_yan">{{ codeTip }}</p>
            </div>
            <div class="alert-input-agree">
              <!-- <input type="checkbox" v-model="agree"/> -->
              <el-checkbox v-model="agree"></el-checkbox>
              我已阅读并同意<a href="javascript:;" target="_blank">《动力金融网注册服务协议》</a>
            </div>
            <div class="alert-input-btn">
              <!-- .prevent表示阻止元素的默认行为(提交按钮的默认行为是提交表单) -->
              <input type="button" class="login-submit"
                     :disabled="!canRegister"
                     :style="{background: bgColor}"
                     @click.prevent="register"
                     value="注册">
            </div>
          </form>
          <div class="login-skip">
            已有账号？ <a href="javascript:;" @click="goLink('/login')">登录</a>
          </div>
        </div>

      </div>
    </div>

    <!--公共底部-->
    <Footer/>
  </div>
</template>

<script>
// @相当于src
import Vue from 'vue'
import Footer from "@/components/Footer";
import Header from "@/components/Header";

export default {
  name: "RegisterView",
  data() {
    return {
      phone: '',
      password: '',
      code: '', // 用户输入的短信验证码
      realCode: '', // 真实的短信验证码
      agree: false,
      phoneTip: '',
      passwordTip: '',
      codeTip: '',
      remainingSendTime: 0,// 短信剩余发送时间
      avgRate: '10.0'
    }
  },
  // 页面未渲染
  created() {
  },
  // 页面已渲染完毕
  mounted() {
    /*Vue.axios.get('http://127.0.0.1/product/avgRate').then(resp => {
      console.log(resp);
      console.log(resp);
      console.log(resp);
      this.avgRate = resp.data.toFixed(2);
    })*/
    Vue.axios.get('http://127.0.0.1/product/avgRate').then(({data}) => {
      this.avgRate = data.toFixed(2);
    })
  },

  components: {Header, Footer},
  methods: {
    goLink(path) {
      this.$router.push(path)
    },
    sendSMS() {
      let url = 'http://127.0.0.1/sms/send/register/' + this.phone;
      Vue.axios.get(url).then(({data}) => {
        this.realCode = data;
        console.log(data);

        // 60秒倒计时
        this.remainingSendTime = 5;

        // 1000毫秒之后执行参数1指定的函数，只执行1次
        //setTimeout(() => console.log("xxx"), 1000)

        // 每秒执行一次, flag标识用于停止该计时器
        let flag = setInterval(() => {
          this.remainingSendTime--;
          if (this.remainingSendTime == 0) {
            clearInterval(flag) // 停止计时器
          }
        }, 1000);


      })
    },
    register() {

      if (!this.agree) {
        // ElementUI 提示框
        this.$alert('请勾选同意协议', '提示', {
          confirmButtonText: '确定',
        });

        return;
      }

      // 当参数是字符串时，则以普通方式提交数据，如果是一个对象，则发送json格式的数据
      let data = "phone=" + this.phone + "&loginPassword=" + this.password + "&code=" + this.code;
      Vue.axios.post('http://127.0.0.1/user/register', data).then(({data}) => {
        if (data.success) {
          this.goLink("/login")
        }
        if (data.msg) {
          alert(data.msg);
        }
      })
    },
    checkPhone() {
      if (this.phone == "") {
        this.phoneTip = "请输入手机号！";
      } else if (!this.isPhone) {
        this.phoneTip = "手机格式不正确！";
      } else {
        this.phoneTip = "";
      }
    }
  },
  computed: {
    bgColor() {
      return this.canRegister ? "" : "#ccc";
    },
    canRegister() {
      return this.isPhone
          && this.isPassword
          && this.isCode
          //&& this.agree
          && this.code == this.realCode
    },
    isPhone() {
      return /^1[3-9]\d{9}$/.test(this.phone);
    },
    isPassword() {
      return /^(?=.*[0-9])(?=.*[a-zA-Z])[0-9a-zA-Z]{6,20}$/.test(this.password);
    },
    isCode() {
      return /^\d{6}$/.test(this.code);
    },
    sendText() {
      if (this.remainingSendTime == 0) {
        return "获取验证码";
      } else {
        return "倒计时：" + this.remainingSendTime + "..."
      }
    }
  }
}
</script>

<style scoped>

</style>