import Vue from 'vue'
import axios from 'axios'
import VueAxios from 'vue-axios'

//设置axios的默认值
axios.defaults.baseURL='http://127.0.0.1/';

// 需要登录的url：路径以 指定数组中的元素 为开头的路径
let loginLikeUrl = ['/user/auth'];
// 需要登录的url：精确匹配
let loginEqUrl = [];

//请求拦截器，加入token
axios.interceptors.request.use(function(config){
    //判断需要token的访问服务器地址，加入token
    console.log( "axios.interceptors.request url="+config.url);

    // 判断请求是否需要登录
    let flag = false;
    for (let url of loginLikeUrl) {
        if (config.url.startsWith(url)) {
            flag = true;
            break;
        }
    }
    if (!flag) // 如果上一个循环没有判断出结果，再执行下次遍历
    for (let url of loginEqUrl) {
        if (config.url == url) {
            flag = true;
            break;
        }
    }

    // 某些请求必须登录才能访问，在前端进行拦截校验
    if( flag ) {
        let token = sessionStorage.getItem("ybl-token");
        // 未登录，强制跳转到登录界面
        if (!token) {
            location.href = 'http://127.0.0.1:8080/login'

            // 取消请求，减轻服务器压力
            return false;
        }
    }

    // 只要请求后台，都会尝试携带用户的id
    let userInfo = sessionStorage.getItem("ylb-userInfo");
    if (userInfo) {
        console.log("userInfo:" + userInfo)
        let user = JSON.parse(userInfo);
        // 将用户ID放在请求头中，后台可以从请求头中获取用户id
        config.headers['uid']= user.id;
    }

    return config;
},function(err){
    console.log('request错误:'+err);
})

//应答拦截器
/*axios.interceptors.response.use(function(resp){
    /!*if( resp && resp.data.code > 1000){
        layx.msg('提示：'+resp.data.msg,{dialogIcon:'warn',position:'ct',width:300});
        if( resp.data.code == 4003 ){
            //重新登录
            window.location.href = '/page/login';
        }
    }*!/
    console.log(resp);
    return resp;
},function(err){
    console.log('response错误:'+err);
})*/


Vue.use(VueAxios, axios)

