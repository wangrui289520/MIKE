function zeroFilling(num) {
    return num < 10 ? "0" + num : num;
}
function formatDate(date) {
    let d = new Date(date);
    let year = d.getFullYear();
    let month = zeroFilling(d.getMonth() + 1); // 0~11
    let day = zeroFilling(d.getDate());
    let hour = zeroFilling(d.getHours());
    let minutes = zeroFilling(d.getMinutes());
    let seconds = zeroFilling(d.getSeconds());

    let result = year + "-" + month + "-" + day + " " + hour + ":" + minutes + ":" + seconds;
    return result;
}

function thousandSplit(s) {
    const str = s.toString()
    const reg = str.indexOf('.') > -1 ? /(\d{1,3})(?=(\d{3})+\.)/g : /(\d{1,3})(?=(\d{3})+$)/g;
    return str.replace(reg, '$1,')
}

// 1,234,567.23
function formatMoney(money) {
    // 如果不是数字
    if (isNaN(money)) {
        return money;
    }
    return "￥" + thousandSplit(money) + "元";
}

function formatPhone(phone) {
    return phone.substr(0, 3) + "******" + phone.substr(9, 2);
}

export {formatDate, formatMoney, formatPhone};