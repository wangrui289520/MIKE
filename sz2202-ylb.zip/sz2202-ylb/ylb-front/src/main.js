import Vue from 'vue'
import App from './App.vue'
import router from './router'

import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
Vue.use(ElementUI);

//导入全局css
import '../public/css/details.css'
import '../public/css/font-awesome.min.css'
import '../public/css/index.css'
import '../public/css/list.css'
import '../public/css/login.css'
import '../public/css/public-head.css'
import '../public/css/reset.css'
import '../public/css/swiper.css'
import '../public/css/user_center.css'
import '../public/css/user_pay.css'
import './utils/request'

Vue.config.productionTip = false

new Vue({
  router,
  render: h => h(App)
}).$mount('#app')
