import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

// 配置路由规则，每添加一个组件，就需要配置对应的路由规则
const routes = [
  {
    path: '/',
    name: 'Register',
    component: () => import('../views/RegisterView'),
    // 定义网页标题
    meta: {
      title: "盈利宝 - 注册"
    }
  },
  {
    path: '/login',
    name: 'Login',
    component: () => import('../views/LoginView'),
    meta: {
      title: "盈利宝 - 登录"
    }
  },
  {
    path: '/index',
    name: 'Index',
    component: () => import('../views/IndexView'),
    meta: {
      title: "盈利宝 - 首页"
    }
  },
  {
    path: '/auth',
    name: 'Auth',
    component: () => import('../views/AuthView'),
    meta: {
      title: "盈利宝 - 用户实名认证"
    }
  },
  {
    path: '/list/:type',
    name: 'List',
    component: () => import('../views/ListView'),
    meta: {
      title: "盈利宝 - 产品列表"
    }
  },
  {
    path: '/user',
    name: 'User',
    component: () => import('../views/UserCenterView'),
    meta: {
      title: "盈利宝 - 个人中心"
    }
  },
  {
    path: '/detail/:id',
    name: 'Detail',
    component: () => import('../views/DetailView'),
    meta: {
      title: "盈利宝 - 产品详情"
    }
  },
  {
    path: '/pay',
    name: 'Pay',
    component: () => import('../views/PayView'),
    meta: {
      title: "盈利宝 - 用户充值"
    }
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

// 在路由离开之前触发
router.beforeEach((to, from, next) => {
  console.log(to.path);

  let isLogin = sessionStorage.getItem("ylb-token") != null;

  if (to.path == "/login" && isLogin) {
    router.push("/index")
    return ;
  }

  if (to.path.startsWith("/detail")) {
    if (!isLogin) {
      location = "/login";
      return ;
    }
  }

  document.title = to.meta.title
  next(); // 真实跳转
})

export default router
