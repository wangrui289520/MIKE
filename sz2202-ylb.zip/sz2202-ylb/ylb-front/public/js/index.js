var swiper1 = new Swiper('.swiper-container.banner-lb', {
    pagination: '.swiper-pagination',
    paginationClickable: true,
    centeredSlides: true,
    autoplay: 3000,
    autoplayDisableOnInteraction: false,
    slidesPerView: 1,
    loop: true
});
