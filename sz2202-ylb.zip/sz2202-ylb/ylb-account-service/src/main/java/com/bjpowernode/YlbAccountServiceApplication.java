package com.bjpowernode;

import com.alibaba.dubbo.spring.boot.annotation.EnableDubboConfiguration;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.bjpowernode.mapper")
@EnableDubboConfiguration
public class YlbAccountServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(YlbAccountServiceApplication.class, args);
    }

}
