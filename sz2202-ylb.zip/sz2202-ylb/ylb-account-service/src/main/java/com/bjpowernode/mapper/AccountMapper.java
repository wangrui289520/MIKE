package com.bjpowernode.mapper;

import org.apache.ibatis.annotations.Param;

import java.math.BigDecimal;

public interface AccountMapper {
    BigDecimal getMoney(Long uid);

    void insert(Long uid);

    int deduction(@Param("uid") Long uid, @Param("money") Integer money);
}
