package com.bjpowernode.service;

import com.alibaba.dubbo.config.annotation.Service;
import com.bjpowernode.mapper.AccountMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
@Service
public class AccountServiceImpl implements AccountService {

    @Autowired
    private AccountMapper accountMapper;

    public BigDecimal getMoney(Long uid) {
        return accountMapper.getMoney(uid);
    }

    @Override
    public void insert(Long uid) {
        accountMapper.insert(uid);
    }

    @Override
    public int deduction(Long uid, Integer money) {
        return accountMapper.deduction(uid, money);
    }
}
