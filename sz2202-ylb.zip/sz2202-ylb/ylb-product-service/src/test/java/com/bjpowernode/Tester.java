package com.bjpowernode;

import org.junit.Test;

import java.math.BigDecimal;

public class Tester {
    @Test
    public void test01() {
        BigDecimal benJin = new BigDecimal(100);
        BigDecimal cycle = new BigDecimal(3);
        BigDecimal rate = new BigDecimal(5.9);
        BigDecimal month = new BigDecimal(12);
        BigDecimal divide = rate.divide(month);
        BigDecimal multiply = divide.multiply(cycle);
        System.out.println(divide);
        System.out.println(multiply);
        BigDecimal shouyi = multiply.multiply(benJin);
        BigDecimal bai = new BigDecimal(100);
        BigDecimal xxx = shouyi.divide(bai);
        System.out.println(xxx);



    }
}
