package com.bjpowernode.mapper;

import com.bjpowernode.model.Product;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

public interface ProductMapper {
    Double getAvgRate();

    Product getNewProduct();

    Product getByTypeAndCycle(@Param("type") Integer type,
                              @Param("cycle") Integer cycle);

    // limit start, length
    List<Product> getByType(@Param("type") Integer type,
                            @Param("start") Integer start,
                            @Param("length") Integer length);

    // 根据类型查询总数据
    Integer getCountByType(Integer type);

    Product getById(Long id);

    int deduction(@Param("pid") Long pid,
                  @Param("money") Integer money);

    void setFull(@Param("pid") Long pid,
                 @Param("date") Date date);

    List<Product> getFullProduct();

    void setStatus(@Param("id") Long id,
                   @Param("status") int status);
}
