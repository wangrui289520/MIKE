package com.bjpowernode.mapper;

import com.bjpowernode.model.Income;

public interface IncomeMapper {
    void insert(Income income);
}
