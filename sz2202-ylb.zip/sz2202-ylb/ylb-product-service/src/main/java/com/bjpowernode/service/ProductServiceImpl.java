package com.bjpowernode.service;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.dubbo.config.annotation.Service;
import com.bjpowernode.mapper.IncomeMapper;
import com.bjpowernode.mapper.ProductMapper;
import com.bjpowernode.model.BidInfo;
import com.bjpowernode.model.Income;
import com.bjpowernode.model.Product;
import com.bjpowernode.vo.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Component // Spring实例化
@Service // dubbo暴露服务
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductMapper productMapper;
    // 为了避免循环依赖，导致某些服务必须先启动
    @Reference(check = false)
    private BidInfoService bidInfoService;

    @Autowired
    private IncomeMapper incomeMapper;

    public Double getAvgRate() {
        return productMapper.getAvgRate();
    }

    public Product getNewProduct() {
        return productMapper.getNewProduct();
    }

    public Product getByTypeAndCycle(Integer type, Integer cycle) {
        return productMapper.getByTypeAndCycle(type, cycle);
    }

    public Page getPage(Integer type, Integer pageSize, Integer currPage) {

        // 查询总记录数
        Integer totalCount = productMapper.getCountByType(type);

        // 计算总页数
        /*Integer totalPage = totalCount / pageSize;
        // 除不尽则页数+1
        if (totalCount % pageSize > 0) {
            totalPage++;
        }*/
        // 计算总页数公式：(总记录数 - 1) / 每页条数 + 1
        Integer totalPage = (totalCount - 1) / pageSize + 1;

        /*
            假设每页10条：
            第1页： limit 0,10
            第2页： limit 1,10
            第3页： limit 2,10
            第4页： limit 3,10
            ...
            第N页：limit (currPage - 1) * pageSize
         */
        Integer start = (currPage - 1) * pageSize;
        List<Product> products = productMapper.getByType(type, start, pageSize);


        Page page = new Page();
        page.setTotalPage(totalPage);
        page.setItems(products);

        return page;
    }

    @Override
    public Product getById(Long id) {
        return productMapper.getById(id);
    }

    @Override
    public int deduction(Long pid, Integer money) {
        return productMapper.deduction(pid, money);
    }

    @Override
    public void setFull(Long pid, Date date) {
        productMapper.setFull(pid, date);
    }

    // 每天凌晨5点中，为满标产品生成收益计划
    @Scheduled(cron = "0 0 5 * * ?")
    public void scanFullProduct() {
        // 查询所有的满标产品(status=1)
        List<Product> fullProducts = productMapper.getFullProduct();
        // 查询每个产品的投资记录，并记录到收益表中
        if (fullProducts != null) {
            for (Product fullProduct : fullProducts) {
                // 根据产品id，查询所有投资记录
                List<BidInfo> bidInfos = bidInfoService.getByProductId(fullProduct.getId());

                for (BidInfo bidInfo : bidInfos) {
                    Income income = new Income();
                    income.setProdId(fullProduct.getId());
                    income.setIncomeStatus(0);
                    income.setBidId(bidInfo.getId());
                    income.setBidMoney(bidInfo.getBidMoney());
                    income.setUid(bidInfo.getUid());

                    // 收益：利息(年利率/12*产品周期*本金/100)
                    double liXi = fullProduct.getRate().doubleValue() / 12 *
                            fullProduct.getCycle().doubleValue() * bidInfo.getBidMoney().doubleValue() / 100;

                    System.out.println(liXi);

                    BigDecimal incomeMoney = new BigDecimal(liXi);
                    income.setIncomeMoney(incomeMoney);
                    // 收益日期：产品满标时间+产品周期
                    Date fullTime = fullProduct.getProductFullTime();
                    // 获取当前时间的 Calendar 对象
                    Calendar instance = Calendar.getInstance();
                    // 根据满标时间重置 instance
                    instance.setTime(fullTime);
                    // 在月单位上加 产品周期(月为单位)
                    instance.add(Calendar.MONTH, fullProduct.getCycle());
                    Date time = instance.getTime();
                    // util.Date ==> sql.Date
                    java.sql.Date incomeDate = new java.sql.Date(time.getTime());
                    income.setIncomeDate(incomeDate);

                    incomeMapper.insert(income);
                }

                // 更新产品的状态为2（满标已生成收益计划）
                productMapper.setStatus(fullProduct.getId(), 2);

            }


        }
    }
}
