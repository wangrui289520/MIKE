package com.bjpowernode;

import com.alibaba.dubbo.spring.boot.annotation.EnableDubboConfiguration;
import com.bjpowernode.service.ProductService;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableDubboConfiguration
@MapperScan("com.bjpowernode.mapper")
@EnableScheduling
public class YlbProductServerApplication {

    public static void main(String[] args) {
        ConfigurableApplicationContext context = SpringApplication.run(YlbProductServerApplication.class, args);

        // 服务启动之后，立即调用一次任务
        ProductService productService = context.getBean(ProductService.class);
        productService.scanFullProduct();
    }

}
