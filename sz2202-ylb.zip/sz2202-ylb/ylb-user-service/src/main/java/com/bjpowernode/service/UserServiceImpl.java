package com.bjpowernode.service;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.dubbo.config.annotation.Service;
import com.bjpowernode.mapper.UserMapper;
import com.bjpowernode.model.User;
import com.bjpowernode.utils.MD5Utils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpSession;
import java.util.Date;

@Component // Spring实例化
@Service // dubbo 暴露服务
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;

    @Reference(check = false)
    private AccountService accountService;

    @Override
    public void register(User user) {
        System.out.println("插入之前：" + user);
        System.out.println("插入之前：" + user);
        System.out.println("插入之前：" + user);

        userMapper.insert(user);

        System.out.println("插入后：" + user);
        System.out.println("插入后：" + user);
        System.out.println("插入后：" + user);

        accountService.insert(user.getId());
    }

    @Override
    public boolean checkExists(String phone) {
        return userMapper.checkExists(phone);
    }

    @Override
    public User getLoginUser(String phone, String password) {
        password = MD5Utils.getMD5(password);
        return userMapper.getLoginUser(phone, password);
    }

    @Override
    public User getByPhone(String phone) {
        return userMapper.getByPhone(phone);
    }

    @Override
    public Integer getCount() {
        return userMapper.getCount();
    }

    @Override
    public void realName(Long userId, String name, String idCard) {
        userMapper.realName(userId, name, idCard);
    }

    @Override
    public void updateLastLoginTime(String phone) {
        userMapper.updateLastLoginTime(phone, new Date());
    }
}
