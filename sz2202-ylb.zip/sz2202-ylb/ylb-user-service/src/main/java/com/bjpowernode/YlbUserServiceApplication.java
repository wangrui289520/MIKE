package com.bjpowernode;

import com.alibaba.dubbo.spring.boot.annotation.EnableDubboConfiguration;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
// 扫描mybatis组件
@MapperScan("com.bjpowernode.mapper")
// 启用dubbo
@EnableDubboConfiguration
public class YlbUserServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(YlbUserServiceApplication.class, args);
    }

}
