package com.bjpowernode.mapper;

import com.bjpowernode.model.User;
import org.apache.ibatis.annotations.Param;

import java.util.Date;

public interface UserMapper {
    void insert(User user);

    boolean checkExists(String phone);

    User getLoginUser(@Param("phone") String phone,
                      @Param("password") String password);

    User getByPhone(String phone);

    Integer getCount();

    void realName(@Param("userId") Long userId,
                  @Param("name") String name,
                  @Param("idCard") String idCard);

    void updateLastLoginTime(@Param("phone") String phone,
                             @Param("date") Date date);
}
