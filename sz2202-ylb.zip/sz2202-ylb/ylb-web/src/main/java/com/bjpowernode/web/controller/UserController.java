package com.bjpowernode.web.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.fastjson.JSONObject;
import com.bjpowernode.constants.Result;
import com.bjpowernode.model.User;
import com.bjpowernode.service.UserService;
import com.bjpowernode.utils.HttpClientUtils;
import com.bjpowernode.utils.MD5Utils;
import com.bjpowernode.vo.RealNameResultVo;
import com.bjpowernode.web.config.JDWXRealNameConfig;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@RestController
@RequestMapping("user")
public class UserController {
    @Reference(check = false)
    private UserService userService;

    @Autowired
    private RedisTemplate redisTemplate;

    @Autowired
    private JDWXRealNameConfig jdwxRealNameConfig;

    @GetMapping("auth/{name}/{idCard}")
    public String auth(@PathVariable String name, @PathVariable String idCard, @RequestHeader("uid") Long userId) throws Exception {

        String url = jdwxRealNameConfig.getUrl();
        String appkey = jdwxRealNameConfig.getAppkey();
        Map<String, String> params = new HashMap<>();
        params.put("name", name);
        params.put("certNo", idCard);
        params.put("appkey", appkey);
        /*
            {
                "code": "10000",
                "charge": false,
                "remain": 1305,
                "msg": "查询成功",
                "result": {
                    "code": "000000",
                    "serialNo": "201707110956216762709752427036",
                    "success": "true",
                    "message": "一致",
                    "comfirm": "jd_credit_two"
                }
            }
         */
        //String result = HttpClientUtils.doGet(url, params);
        String result = "{\"code\":\"10000\",\"charge\":false,\"remain\":0,\"msg\":\"查询成功\",\"result\":{\"code\":\"111113\",\"success\":\"true\",\"message\":\"不确定\",\"serialNo\":\"202206230839025855912222819797\",\"comfrom\":\"jd_credit_two\"},\"requestId\":\"8bb6c9853a464cad8042b31a74da12b8\"}";

        System.out.println(result);

        ObjectMapper mapper = new ObjectMapper();
        RealNameResultVo realNameResultVo = mapper.readValue(result, RealNameResultVo.class);
        // 认证成功，更新数据库
        if (realNameResultVo.getResult().getSuccess()) {
            userService.realName(userId, name, idCard);
        }

        return result;
    }

    @GetMapping("userCount")
    public Integer getUserCount() {
        return userService.getCount();
    }


    @PostMapping("register")
    public Map register(User user, String code) {
        // 判断短信验证码
        checkCode(user.getPhone(), code);

        // 验证手机号
        checkPhone(user.getPhone());

        // 验证密码
        checkPassword(user.getLoginPassword());

        // 密码MD5加密
        String password = MD5Utils.getMD5(user.getLoginPassword());
        user.setLoginPassword(password);

        // 完成注册
        userService.register(user);

        return Result.SUC;
    }

    private void checkPassword(String loginPassword) {
        if (StringUtils.isEmpty(loginPassword)) {
            throw new RuntimeException("密码不能为空！");
        } else {
            boolean isPwd = Pattern.matches("^(?=.*[0-9])(?=.*[a-zA-Z])[0-9a-zA-Z]{6,20}$", loginPassword);
            if (!isPwd) {
                throw new RuntimeException("密码不符合要求！");
            }
        }
    }

    @PostMapping("loginForSms")
    public Map loginForSms(String phone, String code) {

        String realCode = (String) redisTemplate.opsForValue().get("smsCode:login:"+phone);

        if (StringUtils.isEmpty(code)) {
            throw new RuntimeException("请填写验证码！");
        } else if (!code.equals(realCode)) {
            throw new RuntimeException("验证码不正确！");
        } else {
            User user = userService.getByPhone(phone);
            if (user == null) {
                throw new RuntimeException("该手机号码未注册！");
            }

            updateLastLoginTime(phone);

            // 手动为客户端创建一个令牌
            String token = UUID.randomUUID().toString().replace("-", "");

            Map result = new HashMap();
            result.put("success", true);
            result.put("token", token);
            result.put("loginUser", user);

            return result;
        }

    }

    private void updateLastLoginTime(String phone) {
        userService.updateLastLoginTime(phone);
    }

    @PostMapping("loginForPwd")
    public Map loginForPwd(String phone, String password) {
        User user = userService.getLoginUser(phone, password);

        if (user == null) {
            throw new RuntimeException("账号或密码不正确！");
        }

        updateLastLoginTime(phone);

        /*
            当服务器创建session时候，会自动给客户端分配一个session的标识（Cookie:JSESSIONID）
            客户端（浏览器）在访问服务器的时候，会将这个标识自动发送给服务器，进而找到与客户端
            对应的session，然后从session获取到用户的数据，来判断是否登录。

            但是，前后端完全分离的情况下，后端程序和前端程序部署在不同的服务器下，由于浏览器的
            安全问题，cookie不能跨域传递，导致无法获得session，因此用户相关的信息，即便保存
            到session，后续也很难获取服务器给客户端分配的session对象。

            解决方案：通过token（令牌）机制！即在服务器端，手动创建一个 token(类似Cooke的JSESSIONID)
                客户端拿到这个令牌之后，将令牌存储到 sessionStorage(专门用于在客户端存储数据) 对象中，
                而客户端在访问服务器的时候，将该令牌再传递给服务器，服务器就可以通过这个令牌来判断用户是否登陆
         */


        // 手动为客户端创建一个令牌
        String token = UUID.randomUUID().toString().replace("-", "");

        Map result = new HashMap();
        result.put("success", true);
        result.put("token", token);
        result.put("loginUser", user);


        return result;
    }

    private void checkPhone(String phone) {
        if (StringUtils.isBlank(phone)) {
            throw new RuntimeException("手机号不能为空！");
        } else {
            boolean isPhone = Pattern.matches("^1[3-9]\\d{9}$", phone);
            if (!isPhone) {
                throw new RuntimeException("手机格式不正确！");
            } else {
                // 判断是否已注册
                boolean exists = userService.checkExists(phone);
                if (exists) {
                    throw new RuntimeException("手机已被注册！");
                }
            }
        }
    }

    private void checkCode(String phone, String code) {
        if (StringUtils.isBlank(code)) {
            throw new RuntimeException("短信验证码不能为空！");
        } else {
            //设置 redisTemplate 对象 key 的序列化方式
            redisTemplate.setKeySerializer(new StringRedisSerializer());
            String key = "smsCode:register:" + phone;
            String realCode = (String) redisTemplate.opsForValue().get(key);

            boolean isCode = Pattern.matches("^\\d{6}$", code);
            if (!isCode) {
                throw new RuntimeException("短信验证码格式不正确！");
            } else if (!code.equals(realCode)) {
                throw new RuntimeException("短信验证码不正确！");
            }
        }
    }

}
