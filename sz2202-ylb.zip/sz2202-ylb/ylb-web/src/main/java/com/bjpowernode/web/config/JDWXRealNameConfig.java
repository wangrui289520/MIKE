package com.bjpowernode.web.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties(prefix = "jdwx.realname")
public class JDWXRealNameConfig {
    private String appkey;
    private String url;
}
