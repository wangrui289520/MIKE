package com.bjpowernode.web.advice;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.Map;

@ControllerAdvice // 可以对Controller进行增强
public class MyExceptionHandler {

    // 针对 Exception包括其子类异常进行统一的处理
    @ExceptionHandler(Exception.class)
    @ResponseBody
    public Map exceptionHandler(Exception e) {

        e.printStackTrace();

        return new HashMap(){{
            put("success", false);
            put("msg", e.getMessage());
        }};
    }
}
