package com.bjpowernode.web.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.bjpowernode.service.AccountService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;

@RestController
@RequestMapping("account")
public class AccountController {

    @Reference(check = false)
    private AccountService accountService;

    @GetMapping("money")
    public BigDecimal getMoney(@RequestHeader("uid") Long uid) {

        System.out.println(uid);
        System.out.println(uid);
        System.out.println(uid);

        BigDecimal money = accountService.getMoney(uid);
        System.out.println(money);
        System.out.println(money);
        System.out.println(money);

        return money;
    }
}
