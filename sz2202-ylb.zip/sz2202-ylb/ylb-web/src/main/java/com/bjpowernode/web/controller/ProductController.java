package com.bjpowernode.web.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.bjpowernode.model.Product;
import com.bjpowernode.service.ProductService;
import com.bjpowernode.vo.Page;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("product")
public class ProductController {

    @Reference(check = false)
    private ProductService productService;

    @Value("${pageSize}")
    private Integer pageSize;

    @GetMapping("avgRate")
    public double getAvgRate() {
        return productService.getAvgRate();
    }

    @GetMapping("{id}")
    public Product getById(@PathVariable Long id) {
        return productService.getById(id);
    }

    @GetMapping("newProduct")
    public Product newProduct() {
        return productService.getNewProduct();
    }

    @GetMapping("{type}/{cycle}")
    public Product getProduct(@PathVariable Integer type,
                              @PathVariable Integer cycle) {
        return productService.getByTypeAndCycle(type, cycle);
    }

    @GetMapping("/page/{type}/{currPage}")
    public Page getPage(@PathVariable Integer type,
                           @PathVariable Integer currPage) {
        return productService.getPage(type, pageSize, currPage);
    }
}
