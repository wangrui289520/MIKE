package com.bjpowernode.web.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.bjpowernode.constants.Result;
import com.bjpowernode.model.BidInfo;
import com.bjpowernode.service.BidInfoService;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("bid")
public class BidInfoController {

    @Reference(check = false)
    private BidInfoService bidInfoService;

    @GetMapping("sumMoney")
    public BigDecimal getSumMoney() {
        return bidInfoService.getSumMoney();
    }

    @GetMapping("top3")
    public List<Map> getTop3() {
        return bidInfoService.getTop3();
    }

    @GetMapping("limit/{limit}")
    public List<BidInfo> getForLimit(@RequestHeader("uid") Integer uid, @PathVariable Integer limit) {
        return bidInfoService.getForLimit(uid, limit);
    }

    @GetMapping("{productId}/{limit}")
    public List<BidInfo> getListByProductId(@PathVariable Long productId,
                                            @PathVariable Integer limit) {
        return bidInfoService.getListByProductId(productId, limit);
    }

    // 投资接口
    @PostMapping
    public Map bid(@RequestHeader("uid") Long uid, Integer money, Long pid) {

        bidInfoService.bid(uid, pid, money);

        return Result.SUC;
    }

}
