package com.bjpowernode.web.controller;

import com.bjpowernode.web.config.SmsConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aliyun.dysmsapi20170525.Client;
import com.aliyun.dysmsapi20170525.models.SendSmsRequest;
import com.aliyun.dysmsapi20170525.models.SendSmsResponse;
import com.aliyun.tea.TeaModel;
import com.aliyun.teaopenapi.models.Config;
import com.aliyun.teautil.Common;
import com.aliyun.teautil.models.RuntimeOptions;

import javax.servlet.http.HttpSession;
import java.util.Map;
import java.util.concurrent.TimeUnit;

// 短信接口服务
@RestController
@RequestMapping("sms")
public class SMSController {

    @Autowired
    private RedisTemplate redisTemplate;

    @Autowired
    private SmsConfig smsConfig;

    /**
     * @param phone
     * @param type  验证码的类型：register:注册的，login:登录的
     * @return
     * @throws Exception
     */
    @GetMapping("/send/{type}/{phone}")
    public String send(@PathVariable String phone, @PathVariable String type) throws Exception {
        Config config = new Config()
                // 您的 AccessKey ID
                .setAccessKeyId(smsConfig.getAccessKeyId())
                // 您的 AccessKey Secret
                .setAccessKeySecret(smsConfig.getAccessKeySecret());
        // 访问的域名
        config.endpoint = smsConfig.getEndpoint();

        // 生成随机验证码
        String s = Math.random() + ""; // 0.54564156345643...
        String code = s.substring(2, 8);
        System.out.println(code);

        //设置 redisTemplate 对象 key 的序列化方式
        redisTemplate.setKeySerializer(new StringRedisSerializer());
        String key = "smsCode:" + type + ":" + phone;
        redisTemplate.opsForValue().set(key, code, 300, TimeUnit.SECONDS);

        // 没钱了，暂时注释掉
        if (smsConfig.getRealSend()) {

            System.out.println("真实发送短信验证码！");
            System.out.println("真实发送短信验证码！");
            System.out.println("真实发送短信验证码！");
            System.out.println("真实发送短信验证码！");
            System.out.println("真实发送短信验证码！");

            Client client = new Client(config);
            SendSmsRequest sendSmsRequest = new SendSmsRequest()
                    .setSignName(smsConfig.getSignName())
                    .setTemplateCode(smsConfig.getTemplateCode())
                    .setPhoneNumbers(phone)
                    .setTemplateParam("{\"code\":\"" + code + "\"}");
            RuntimeOptions runtime = new RuntimeOptions();
            SendSmsResponse resp = client.sendSmsWithOptions(sendSmsRequest, runtime);

            Map<String, Object> result = TeaModel.buildMap(resp);
            // body: {Message=OK, RequestId=BDB77D59-9729-5A87-BA17-0DB2C2C960A0, BizId=396306755342085578^0, Code=OK}
            Map<String, String> body = (Map<String, String>) result.get("body");
            System.out.println(body);
            String flag = body.get("Code");

            if ("OK".equals(flag)) {
                return code;
            } else {
                // 发送不成功，什么都不返回
                return "";
            }
        }

        return code;
    }

}
