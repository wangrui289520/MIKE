package com.bjpowernode;

import com.bjpowernode.utils.HttpClientUtils;
import com.bjpowernode.vo.RealNameResultVo;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.UUID;
import java.util.regex.Pattern;

class YlbWebApplicationTests {

    @Test
    void contextLoads() {
        String uuid = UUID.randomUUID().toString();
        System.out.println(uuid);

        String token = uuid.replace("-", "");
        /*
            replace和replaceAll的区别：
                replace：只能替换指定的普通字符串
                replaceAll：支持正则表达式替换
         */
        String token2 = uuid.replaceAll("\\d", "");
        System.out.println(token);
        System.out.println(token2);
    }

    @Test
    void xxx() throws Exception {
        //String result = HttpClientUtils.doGet("https://way.jd.com/YOUYU365/jd_credit_two?name=陈齐&certNo=320323198902031650&appkey=d3382db143b7b4e1a84ac19b5f28d19f");
        String result = "{\"code\":\"10000\",\"charge\":false,\"remain\":0,\"msg\":\"查询成功\",\"result\":{\"code\":\"000000\",\"success\":\"true\",\"message\":\"一致\",\"serialNo\":\"202206211152038943253023539223\",\"comfrom\":\"jd_credit_two\"},\"requestId\":\"a43fb154347e4939a6ccf356c8425bfa\"}";
        System.out.println(result);

        ObjectMapper mapper = new ObjectMapper();
        RealNameResultVo realNameResultVo = mapper.readValue(result, RealNameResultVo.class);
        System.out.println(realNameResultVo);


    }

}
