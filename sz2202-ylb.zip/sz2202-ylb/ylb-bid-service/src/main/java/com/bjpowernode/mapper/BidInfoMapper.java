package com.bjpowernode.mapper;

import com.bjpowernode.model.BidInfo;
import org.apache.ibatis.annotations.Param;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

public interface BidInfoMapper {
    BigDecimal getSumMoney();

    List<Map> getTop3();

    List<BidInfo> getForLimit(@Param("uid") Integer uid,
                              @Param("limit") Integer limit);

    List<BidInfo> getListByProductId(@Param("pid") Long productId,
                                     @Param("limit") Integer limit);

    void insert(BidInfo bidInfo);

    List<BidInfo> getByProductId(Long id);
}
