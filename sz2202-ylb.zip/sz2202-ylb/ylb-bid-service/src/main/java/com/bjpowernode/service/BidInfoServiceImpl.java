package com.bjpowernode.service;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.dubbo.config.annotation.Service;
import com.bjpowernode.mapper.BidInfoMapper;
import com.bjpowernode.model.BidInfo;
import com.bjpowernode.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Component
@Service
public class BidInfoServiceImpl implements BidInfoService {
    @Autowired
    private BidInfoMapper bidInfoMapper;

    @Reference(check = false)
    private AccountService accountService;

    @Reference(check = false)
    public ProductService productService;

    public BigDecimal getSumMoney() {
        return bidInfoMapper.getSumMoney();
    }

    @Override
    public List<Map> getTop3() {
        return bidInfoMapper.getTop3();
    }

    public List<BidInfo> getForLimit(Integer uid, Integer limit) {
        return bidInfoMapper.getForLimit(uid, limit);
    }

    @Override
    public List<BidInfo> getListByProductId(Long productId, Integer limit) {
        return bidInfoMapper.getListByProductId(productId, limit);
    }

    @Override
    public synchronized void bid(Long uid, Long pid, Integer money) {
        // 查询用户资金信息
        BigDecimal accountMoney = accountService.getMoney(uid);
        // 查询产品信息
        Product product = productService.getById(pid);

        // 判断资金是否充足
        double v = accountMoney.doubleValue();
        if (v < money) {
            throw new RuntimeException("账户余额不足！");
        }

        // 判断产品剩余可购买金额是否充足
        double v1 = product.getLeftProductMoney().doubleValue();
        if (v1 < money) {
            throw new RuntimeException("产品可购买余额不足！");
        }

        // 判断购买金额是否符合产品的最小最大金额
        double min = product.getBidMinLimit().doubleValue();
        double max = product.getBidMaxLimit().doubleValue();
        if (money < min || money > max) {
            throw new RuntimeException("购买金额必须在" + min + "~" + max + "之间！");
        }

        // 扣除用户资金
        int a = accountService.deduction(uid, money);
        if (a == 0) {
            throw new RuntimeException("账户余额不足！");
        }

        // 扣除产品的可购买金额
        int b = productService.deduction(pid, money);
        if (b == 0) {
            throw new RuntimeException("产品可购买余额不足！");
        }
        // 向投资记录表中添加投资记录
        BidInfo bidInfo = new BidInfo();
        bidInfo.setUid(uid);
        bidInfo.setBidMoney(new BigDecimal(money));
        bidInfo.setBidTime(new Date());
        bidInfo.setBidStatus(1);
        bidInfo.setProdId(pid);


        bidInfoMapper.insert(bidInfo);
        // 如果可购买金额是否小于 min，则更新产品状态为满标，并更新满标时间
        Double leftMoney = product.getLeftProductMoney().doubleValue() - money;
        if (leftMoney < min) {
            productService.setFull(pid, new Date());
        }
    }

    @Override
    public List<BidInfo> getByProductId(Long id) {
        return bidInfoMapper.getByProductId(id);
    }
}
